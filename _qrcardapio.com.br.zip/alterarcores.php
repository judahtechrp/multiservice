<style>

#preloader{
    background-color: <?php echo "{$cor_loading}";?> !important;
}

.box_style_2 h2.inner{
    background-color: <?php echo "{$cor_topo}";?> !important;
    color: <?php echo "{$cor_titulo_produtos}";?> !important;
}
    header.sticky{
    background-color: <?php echo "{$cor_topo}";?> !important;    
    
    }
    
    header{
    background-color: <?php echo "{$cor_topo}";?> !important;    
    
    }
    
    
</style>